# Weave — Frontend

Single-file, dependency-free React app (React + Babel loaded via CDN — no
build step, nothing to `npm install`). Talks to the Weave FastAPI backend.

## Run locally

```bash
python -m http.server 3000
```
Open http://localhost:3000

## Point it at your backend

Open `index.html` and edit the `API_BASE` constant near the top of the
`<script type="text/babel">` block:

```js
const API_BASE = "https://your-backend-url.com";
```

## Deploy

Any static host works since it's a single HTML file:

- **Vercel**: `vercel deploy` from this folder (vercel.json included)
- **Netlify**: drag-and-drop this folder onto Netlify's dashboard, or `netlify deploy`
- **GitHub Pages**: push this folder to a repo, enable Pages on the branch

No environment variables, no build command, no framework install needed.
