import { Router, type IRouter } from "express";
import { and, asc, desc, eq } from "drizzle-orm";
import {
  db,
  weaveCapturesTable,
  weaveCompilationsTable,
  weaveEntitiesTable,
  weaveRelationsTable,
  weaveRisksTable,
  weaveSourcesTable,
} from "@workspace/db";
import {
  CompileContextBody,
  CompileContextResponse,
  CreateCaptureBody,
  CreateCaptureResponse,
  GetEntityParams,
  GetEntityResponse,
  GetWorkspaceStateResponse,
  ListCapturesResponse,
  ListCompilationsResponse,
  ListEntitiesResponse,
  ListRisksResponse,
  ResolveRiskParams,
  ResolveRiskResponse,
  SyncSourceParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

function iso(value: Date | null) {
  return value?.toISOString() ?? null;
}

function mapSource(source: typeof weaveSourcesTable.$inferSelect) {
  return {
    id: source.id,
    name: source.name,
    count: source.count,
    status: source.status as "synced" | "syncing" | "ready",
    lastSyncedAt: iso(source.lastSyncedAt),
  };
}

function mapRisk(risk: typeof weaveRisksTable.$inferSelect) {
  return {
    id: risk.id,
    severity: risk.severity as "high" | "medium" | "low",
    title: risk.title,
    body: risk.body,
    status: risk.status as "open" | "resolved",
    createdAt: risk.createdAt.toISOString(),
    resolvedAt: iso(risk.resolvedAt),
  };
}

function mapCompilation(compilation: typeof weaveCompilationsTable.$inferSelect) {
  return {
    id: compilation.id,
    goal: compilation.goal,
    rawTokens: compilation.rawTokens,
    compiledTokens: compilation.compiledTokens,
    reduction: compilation.reduction,
    steps: compilation.steps,
    included: compilation.included,
    excluded: compilation.excluded,
    createdAt: compilation.createdAt.toISOString(),
  };
}

function mapCapture(capture: typeof weaveCapturesTable.$inferSelect) {
  return {
    id: capture.id,
    kind: capture.kind as "handwriting" | "voice",
    title: capture.title,
    fields: capture.fields,
    source: capture.source,
    createdAt: capture.createdAt.toISOString(),
  };
}

function createFields(transcript: string | null) {
  if (!transcript?.trim()) {
    return [{ label: "note", value: "No transcription was provided." }];
  }

  return transcript
    .split(/\r?\n+/)
    .map((line) => line.trim())
    .filter(Boolean)
    .slice(0, 12)
    .map((line, index) => {
      const separator = line.indexOf(":");
      if (separator > 0 && separator < 32) {
        return { label: line.slice(0, separator).trim().toLowerCase(), value: line.slice(separator + 1).trim() };
      }
      return { label: index === 0 ? "note" : `note ${index + 1}`, value: line };
    });
}

async function getWorkspaceContext() {
  const [captures, entities, risks] = await Promise.all([
    db.select().from(weaveCapturesTable).orderBy(desc(weaveCapturesTable.createdAt)),
    db.select().from(weaveEntitiesTable).orderBy(asc(weaveEntitiesTable.label)),
    db.select().from(weaveRisksTable).where(eq(weaveRisksTable.status, "open")).orderBy(desc(weaveRisksTable.createdAt)),
  ]);
  return { captures, entities, risks };
}

function compileFromContext(goal: string, context: Awaited<ReturnType<typeof getWorkspaceContext>>) {
  const sourceText = context.captures
    .map((capture) => `${capture.title}\n${capture.fields.map((field) => `${field.label}: ${field.value}`).join("\n")}`)
    .join("\n\n");
  const rawTokens = Math.max(1, Math.ceil(sourceText.split(/\s+/).filter(Boolean).length * 1.35));
  const compiledTokens = Math.max(1, Math.ceil(rawTokens * (rawTokens > 80 ? 0.35 : 0.75)));
  const included = context.captures.slice(0, 5).map((capture) => `${capture.title} · ${capture.source}`);
  const excluded = context.captures.slice(5).map((capture) => capture.title);
  if (context.entities.length) included.push(`${context.entities.length} resolved entities`);
  if (context.risks.length) included.push(`${context.risks.length} open contradictions`);

  return {
    rawTokens,
    compiledTokens,
    reduction: Math.max(0, Math.round((1 - compiledTokens / rawTokens) * 100)),
    steps: [
      { title: "Read the goal", detail: `Scoped the workspace search around “${goal}”.` },
      { title: "Gather available context", detail: `${context.captures.length} capture${context.captures.length === 1 ? "" : "s"}, ${context.entities.length} entit${context.entities.length === 1 ? "y" : "ies"}, and ${context.risks.length} open risk${context.risks.length === 1 ? "" : "s"} are available.` },
      { title: "Reduce the noise", detail: `Selected the most recent records and preserved their original source labels.` },
      { title: "Compile the bundle", detail: `${rawTokens.toLocaleString()} → ${compiledTokens.toLocaleString()} tokens from the context currently in this workspace.` },
    ],
    included: included.length ? included : ["No records selected"],
    excluded: excluded.length ? excluded : ["No records excluded"],
  };
}

router.get("/workspace/state", async (_req, res): Promise<void> => {
  const [sources, risks, entities, relations, compilations, captures] = await Promise.all([
    db.select().from(weaveSourcesTable).orderBy(asc(weaveSourcesTable.id)),
    db.select().from(weaveRisksTable).orderBy(desc(weaveRisksTable.createdAt)),
    db.select().from(weaveEntitiesTable).orderBy(asc(weaveEntitiesTable.label)),
    db.select().from(weaveRelationsTable).orderBy(asc(weaveRelationsTable.id)),
    db.select().from(weaveCompilationsTable).orderBy(desc(weaveCompilationsTable.createdAt)),
    db.select({ id: weaveCapturesTable.id }).from(weaveCapturesTable),
  ]);
  const latest = compilations[0];
  const data = {
    stats: {
      openRisks: risks.filter((risk) => risk.status === "open").length,
      aliases: entities.reduce((total, entity) => total + entity.aliases.length, 0),
      compilations: compilations.length,
      captures: captures.length,
      reduction: latest?.reduction ?? 0,
    },
    sources: sources.map(mapSource),
    risks: risks.map(mapRisk),
    entities,
    relations: relations.map(({ sourceId, targetId, label }) => ({ sourceId, targetId, label })),
    latestCompilation: latest ? mapCompilation(latest) : null,
  };
  res.json(GetWorkspaceStateResponse.parse(data));
});

router.get("/entities", async (_req, res): Promise<void> => {
  const entities = await db.select().from(weaveEntitiesTable).orderBy(asc(weaveEntitiesTable.label));
  res.json(ListEntitiesResponse.parse(entities));
});

router.get("/entities/:entityId", async (req, res): Promise<void> => {
  const params = GetEntityParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [entity] = await db.select().from(weaveEntitiesTable).where(eq(weaveEntitiesTable.id, params.data.entityId));
  if (!entity) {
    res.status(404).json({ error: "Entity not found" });
    return;
  }
  res.json(GetEntityResponse.parse(entity));
});

router.get("/compilations", async (_req, res): Promise<void> => {
  const compilations = await db.select().from(weaveCompilationsTable).orderBy(desc(weaveCompilationsTable.createdAt));
  res.json(ListCompilationsResponse.parse(compilations.map(mapCompilation)));
});

router.post("/context/compile", async (req, res): Promise<void> => {
  const parsed = CompileContextBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const context = await getWorkspaceContext();
  if (!context.captures.length && !context.entities.length) {
    res.status(400).json({ error: "Add a capture or connect a source before compiling context." });
    return;
  }
  const result = compileFromContext(parsed.data.goal.trim(), context);
  const [compilation] = await db.insert(weaveCompilationsTable).values({
    id: crypto.randomUUID(),
    goal: parsed.data.goal.trim(),
    ...result,
  }).returning();
  res.status(201).json(CompileContextResponse.parse(mapCompilation(compilation)));
});

router.get("/captures", async (_req, res): Promise<void> => {
  const captures = await db.select().from(weaveCapturesTable).orderBy(desc(weaveCapturesTable.createdAt));
  res.json(ListCapturesResponse.parse(captures.map(mapCapture)));
});

router.post("/capture", async (req, res): Promise<void> => {
  const parsed = CreateCaptureBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const transcript = parsed.data.transcript?.trim() ?? null;
  if (!transcript) {
    res.status(400).json({ error: "A transcription or note body is required." });
    return;
  }
  const lines = transcript.split(/\r?\n+/).map((line) => line.trim()).filter(Boolean);
  const title = lines[0].replace(/^[#*-]\s*/, "").slice(0, 80) || `${parsed.data.kind === "voice" ? "Voice" : "Handwritten"} capture`;
  const [capture] = await db.insert(weaveCapturesTable).values({
    id: crypto.randomUUID(),
    kind: parsed.data.kind,
    title,
    fields: createFields(transcript),
    source: parsed.data.kind === "voice" ? "Manual voice transcript" : "Manual note",
    transcript,
  }).returning();
  res.status(201).json(CreateCaptureResponse.parse(mapCapture(capture)));
});

router.get("/risks", async (_req, res): Promise<void> => {
  const risks = await db.select().from(weaveRisksTable).orderBy(desc(weaveRisksTable.createdAt));
  res.json(ListRisksResponse.parse(risks.map(mapRisk)));
});

router.post("/risks/:riskId/resolve", async (req, res): Promise<void> => {
  const params = ResolveRiskParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [risk] = await db.update(weaveRisksTable)
    .set({ status: "resolved", resolvedAt: new Date() })
    .where(and(eq(weaveRisksTable.id, params.data.riskId), eq(weaveRisksTable.status, "open")))
    .returning();
  if (!risk) {
    res.status(404).json({ error: "Open risk not found" });
    return;
  }
  res.json(ResolveRiskResponse.parse(mapRisk(risk)));
});

router.post("/sources/:source/sync", async (req, res): Promise<void> => {
  const params = SyncSourceParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (params.data.source !== "capture") {
    res.status(404).json({ error: "This source is not connected to the workspace." });
    return;
  }
  const count = await db.select({ id: weaveCapturesTable.id }).from(weaveCapturesTable);
  res.json({
    id: "capture",
    name: "Manual captures",
    count: `${count.length} capture${count.length === 1 ? "" : "s"}`,
    status: "ready",
    lastSyncedAt: new Date().toISOString(),
  });
});

export default router;