import { useMemo, useState, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { Link, Route, Switch, useLocation, useParams } from 'wouter';
import {
  Activity, ArrowDownRight, ArrowUpRight, AudioLines, Check, CheckCircle2,
  ChevronRight, CircleDot, Clock3, Code2, Database, FileText, GitBranch, Github,
  Inbox, Layers3, Link2, Loader2, MessageSquare, Mic, Network, NotebookPen, PenLine, Plus,
  RefreshCw, Search, Send, Settings2, ShieldAlert, Sparkles, Terminal, TriangleAlert,
  Unplug, Waves, X, Zap
} from 'lucide-react';
import {
  getGetEntityQueryKey, getGetWorkspaceStateQueryKey, getHealthCheckQueryKey,
  getListCapturesQueryKey, getListCompilationsQueryKey, getListEntitiesQueryKey,
  getListRisksQueryKey, useCompileContext, useCreateCapture, useGetEntity,
  useGetWorkspaceState, useHealthCheck, useListCaptures, useListCompilations,
  useListEntities, useListRisks, useResolveRisk, useSyncSource
} from '@workspace/api-client-react';
import type { Capture, Entity, Risk, Source } from '@workspace/api-client-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';

const queryClient = new QueryClient();

const navItems = [
  { href: '/', label: 'Overview', icon: Activity },
  { href: '/graph', label: 'Entity graph', icon: Network },
  { href: '/ask', label: 'Ask Weave', icon: Sparkles },
  { href: '/capture', label: 'Capture', icon: NotebookPen },
  { href: '/risks', label: 'Contradictions', icon: ShieldAlert },
];

function cn(...classes: Array<string | false | undefined>) {
  return classes.filter(Boolean).join(' ');
}

function formatDate(value?: string | null) {
  if (!value) return 'Not yet';
  const date = new Date(value);
  if (Number.isNaN(date.valueOf())) return value;
  return new Intl.DateTimeFormat('en', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }).format(date);
}

function formatTokens(value: number) {
  return value > 999 ? `${(value / 1000).toFixed(value > 9999 ? 0 : 1)}k` : String(value);
}

function PageHeader({ eyebrow, title, description, action }: { eyebrow: string; title: ReactNode; description: string; action?: ReactNode }) {
  return (
    <header className="mb-7 flex flex-col gap-5 border-b border-border/80 pb-6 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <div className="mb-2 flex items-center gap-2 font-mono text-[10px] font-medium uppercase tracking-[0.22em] text-primary">
          <span className="h-1.5 w-1.5 rounded-full bg-accent" /> {eyebrow}
        </div>
        <h1 className="font-serif text-3xl font-bold tracking-[-0.04em] text-foreground sm:text-4xl">{title}</h1>
        <p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">{description}</p>
      </div>
      {action}
    </header>
  );
}

function Skeleton({ className }: { className: string }) {
  return <div className={cn('animate-pulse rounded-md bg-muted', className)} />;
}

function LoadingPanel({ label = 'Loading workspace' }: { label?: string }) {
  return (
    <div className="rounded-xl border border-border bg-card p-5" data-testid="status-loading">
      <div className="mb-4 flex items-center gap-3">
        <Skeleton className="h-8 w-8 rounded-lg" />
        <div className="flex-1"><Skeleton className="h-3 w-32" /><Skeleton className="mt-2 h-2 w-20" /></div>
      </div>
      <Skeleton className="h-28 w-full" />
      <p className="mt-3 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">{label}</p>
    </div>
  );
}

function ErrorPanel({ onRetry, label = 'The workspace could not be read.' }: { onRetry?: () => void; label?: string }) {
  return (
    <div className="flex min-h-40 flex-col items-center justify-center rounded-xl border border-destructive/25 bg-destructive/5 p-6 text-center" data-testid="status-error">
      <TriangleAlert className="mb-3 h-6 w-6 text-destructive" />
      <p className="text-sm font-semibold text-foreground">{label}</p>
      {onRetry && <button onClick={onRetry} className="mt-4 rounded-md bg-foreground px-3 py-2 text-xs font-bold text-background transition hover:bg-primary" data-testid="button-retry">Try again</button>}
    </div>
  );
}

function Metric({ label, value, detail, accent = 'primary' }: { label: string; value: string | number; detail: string; accent?: 'primary' | 'accent' | 'green' }) {
  return (
    <div className="relative overflow-hidden rounded-xl border border-border bg-card p-5 shadow-[0_10px_28px_hsl(225_30%_20%_/_0.04)]" data-testid={`metric-${label.toLowerCase().replaceAll(' ', '-')}`}>
      <div className={cn('absolute right-0 top-0 h-16 w-16 translate-x-6 -translate-y-6 rounded-full opacity-20 blur-2xl', accent === 'accent' ? 'bg-accent' : accent === 'green' ? 'bg-emerald-500' : 'bg-primary')} />
      <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">{label}</p>
      <p className="mt-3 font-serif text-3xl font-bold tracking-[-0.06em]">{value}</p>
      <p className="mt-2 text-xs text-muted-foreground">{detail}</p>
    </div>
  );
}

function SourceIcon({ name }: { name: string }) {
  if (name.toLowerCase().includes('github')) return <Github className="h-4 w-4" />;
  if (name.toLowerCase().includes('slack')) return <MessageSquare className="h-4 w-4" />;
  if (name.toLowerCase().includes('notion')) return <FileText className="h-4 w-4" />;
  return <PenLine className="h-4 w-4" />;
}

function SourceRail({ sources }: { sources: Source[] }) {
  const qc = useQueryClient();
  const sync = useSyncSource();
  const [syncing, setSyncing] = useState<string | null>(null);
  const [providerInfo, setProviderInfo] = useState<string | null>(null);
  const syncOne = (source: Source) => {
    const slug = source.name.toLowerCase().includes('github') ? 'github' : source.name.toLowerCase().includes('slack') ? 'slack' : source.name.toLowerCase().includes('notion') ? 'notion' : 'capture';
    setSyncing(source.id);
    sync.mutate({ source: slug }, {
      onSuccess: () => {
        setSyncing(null);
        qc.invalidateQueries({ queryKey: getGetWorkspaceStateQueryKey() });
      },
      onError: () => setSyncing(null),
    });
  };
  return (
    <section className="rounded-xl border border-border bg-card" data-testid="panel-source-freshness">
      <div className="flex items-center justify-between border-b border-border px-5 py-4">
        <div><p className="font-serif text-lg font-bold">Connected sources</p><p className="mt-0.5 text-xs text-muted-foreground">Only authorized sources appear here</p></div>
        <Database className="h-4 w-4 text-muted-foreground" />
      </div>
      <div className="divide-y divide-border">
        {sources.length === 0 ? <div className="p-5" data-testid="empty-sources">
          <div className="rounded-lg border border-dashed border-border bg-secondary/35 p-4">
            <div className="flex items-start gap-3">
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary"><Link2 className="h-4 w-4" /></div>
              <div><p className="text-sm font-semibold">No sources authorized</p><p className="mt-1 text-xs leading-5 text-muted-foreground">Connect a provider in your workspace settings before Weave can sync context.</p></div>
            </div>
            <div className="mt-4 grid gap-2 sm:grid-cols-3">
              {['GitHub', 'Slack', 'Notion'].map(provider => <button key={provider} onClick={() => setProviderInfo(provider)} className="flex items-center gap-2 rounded-md border border-border bg-card px-3 py-2 text-left text-xs font-semibold transition hover:border-primary hover:text-primary" data-testid={`button-connect-${provider.toLowerCase()}`}><SourceIcon name={provider} /> Connect in workspace</button>)}
            </div>
            {providerInfo && <div className="mt-3 flex items-start gap-2 rounded-md border border-primary/15 bg-primary/[.045] p-3 text-xs text-muted-foreground" data-testid="panel-connect-info"><CircleDot className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" /><span><b className="text-foreground">{providerInfo}</b> authorization is managed in your workspace. No connection was made from this screen.</span></div>}
          </div>
        </div> : sources.map((source) => (
          <div key={source.id} className="group flex items-center gap-3 px-5 py-3.5" data-testid={`row-source-${source.id}`}>
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-secondary text-foreground"><SourceIcon name={source.name} /></div>
            <div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold">{source.name}</p><p className="font-mono text-[10px] text-muted-foreground">{source.count} · {formatDate(source.lastSyncedAt)}</p></div>
            <span className={cn('hidden items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider sm:flex', source.status === 'synced' ? 'text-emerald-700' : source.status === 'syncing' ? 'text-accent' : 'text-muted-foreground')}><span className="h-1.5 w-1.5 rounded-full bg-current" />{source.status}</span>
            <button onClick={() => syncOne(source)} disabled={syncing === source.id} className="rounded-md p-2 text-muted-foreground opacity-0 transition hover:bg-secondary hover:text-foreground group-hover:opacity-100 disabled:opacity-100" aria-label={`Sync ${source.name}`} data-testid={`button-sync-${source.id}`}>{syncing === source.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RefreshCw className="h-3.5 w-3.5" />}</button>
          </div>
        ))}
      </div>
    </section>
  );
}

function RiskCard({ risk, onResolve, resolving }: { risk: Risk; onResolve?: (id: string) => void; resolving?: boolean }) {
  const isResolved = risk.status === 'resolved';
  return (
    <article className={cn('rounded-xl border bg-card p-5 transition hover:shadow-[0_10px_30px_hsl(225_30%_20%_/_0.06)]', isResolved ? 'border-border/70 opacity-70' : risk.severity === 'high' ? 'border-destructive/25' : 'border-border')} data-testid={`card-risk-${risk.id}`}>
      <div className="flex items-start gap-3">
        <div className={cn('mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg', risk.severity === 'high' ? 'bg-destructive/10 text-destructive' : risk.severity === 'medium' ? 'bg-accent/12 text-accent' : 'bg-secondary text-muted-foreground')}><ShieldAlert className="h-4 w-4" /></div>
        <div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">{risk.severity} · {formatDate(risk.createdAt)}</span>{isResolved && <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider text-emerald-700">resolved</span>}</div><h3 className="mt-2 font-serif text-lg font-bold leading-tight">{risk.title}</h3><p className="mt-2 text-sm leading-6 text-muted-foreground">{risk.body}</p></div>
      </div>
      {!isResolved && onResolve && <button onClick={() => onResolve(risk.id)} disabled={resolving} className="mt-4 ml-10 flex items-center gap-2 rounded-md border border-border bg-background px-3 py-2 text-xs font-bold transition hover:border-primary hover:text-primary disabled:opacity-60" data-testid={`button-resolve-${risk.id}`}>{resolving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />} Mark resolved</button>}
    </article>
  );
}

function Shell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const health = useHealthCheck({ query: { queryKey: getHealthCheckQueryKey(), refetchInterval: 30000 } });
  const [mobileNav, setMobileNav] = useState(false);
  const healthUp = health.data?.status === 'ok' || health.data?.status === 'healthy';
  return (
    <div className="noise min-h-[100dvh] bg-background text-foreground">
      <aside className={cn('sidebar-grid fixed inset-y-0 left-0 z-40 flex w-[248px] flex-col border-r border-sidebar-border bg-sidebar text-sidebar-foreground transition-transform duration-300 md:translate-x-0', mobileNav ? 'translate-x-0' : '-translate-x-full')} data-testid="sidebar">
        <div className="flex h-[76px] items-center gap-3 border-b border-sidebar-border px-6">
          <div className="relative flex h-8 w-8 items-center justify-center rounded-[10px] bg-sidebar-primary text-sidebar-primary-foreground"><Waves className="h-[18px] w-[18px]" /><span className="absolute -right-1 -top-1 h-2 w-2 rounded-full bg-accent" /></div>
          <div><p className="font-serif text-[19px] font-bold tracking-[-0.05em]">weave</p><p className="font-mono text-[8px] uppercase tracking-[0.25em] text-sidebar-foreground/45">context os</p></div>
          <button onClick={() => setMobileNav(false)} className="ml-auto rounded p-1 text-sidebar-foreground/60 md:hidden" data-testid="button-close-nav"><X className="h-4 w-4" /></button>
        </div>
       <div className="px-4 pt-7"><p className="mb-3 px-2 font-mono text-[9px] uppercase tracking-[0.22em] text-sidebar-foreground/40">Workspace</p><nav className="space-y-1">{navItems.map(({ href, label, icon: Icon }) => <Link key={href} href={href} onClick={() => setMobileNav(false)} className={cn('group flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-semibold transition', location === href ? 'bg-sidebar-accent text-sidebar-accent-foreground shadow-sm' : 'text-sidebar-foreground/60 hover:bg-sidebar-accent/70 hover:text-sidebar-foreground')} data-testid={`link-nav-${label.toLowerCase().replaceAll(' ', '-')}`}><Icon className={cn('h-4 w-4 transition', location === href ? 'text-sidebar-primary' : 'text-sidebar-foreground/40 group-hover:text-sidebar-foreground')} /><span>{label}</span></Link>)}</nav></div>
         <div className="mt-auto border-t border-sidebar-border p-4"><div className="rounded-xl bg-sidebar-accent/70 p-3.5"><div className="flex items-center gap-2"><span className={cn('h-2 w-2 rounded-full', health.isLoading ? 'bg-sidebar-foreground/30' : healthUp ? 'pulse-dot bg-emerald-400' : 'bg-accent')} /><span className="font-mono text-[10px] uppercase tracking-widest text-sidebar-foreground/70">{health.isLoading ? 'Checking core' : healthUp ? 'Core online' : 'Core offline'}</span></div><p className="mt-2 text-[11px] leading-5 text-sidebar-foreground/45">Context is built from records you capture and sources you authorize.</p></div></div>
      </aside>
      {mobileNav && <button className="fixed inset-0 z-30 bg-foreground/25 md:hidden" onClick={() => setMobileNav(false)} aria-label="Close navigation" data-testid="button-nav-backdrop" />}
      <main className="min-h-[100dvh] md:pl-[248px]">
        <div className="flex h-[76px] items-center justify-between border-b border-border/80 px-5 sm:px-8">
          <button onClick={() => setMobileNav(true)} className="rounded-md border border-border bg-card p-2 md:hidden" data-testid="button-open-nav"><Layers3 className="h-4 w-4" /></button>
          <div className="hidden items-center gap-2 font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground sm:flex"><span className="text-primary">/</span> {location === '/' ? 'overview' : location.slice(1)}</div>
           <div className="ml-auto flex items-center gap-3"><div className="flex h-8 w-8 items-center justify-center rounded-full border border-primary/20 bg-primary/10 text-primary" aria-label="Workspace" data-testid="status-workspace"><Waves className="h-4 w-4" /></div></div>
        </div>
        <div className="weave-grid min-h-[calc(100dvh-76px)] px-5 py-7 sm:px-8 lg:px-10 lg:py-9">{children}</div>
      </main>
    </div>
  );
}

function Overview() {
  const { data, isLoading, isError, refetch } = useGetWorkspaceState({ query: { queryKey: getGetWorkspaceStateQueryKey() } });
  if (isLoading) return <div className="mx-auto max-w-[1420px]"><PageHeader eyebrow="Mission control" title="Workspace overview" description="The shortest path from everything your team knows to what you need next." /><div className="grid gap-5 lg:grid-cols-3"><LoadingPanel /><LoadingPanel /><LoadingPanel /></div></div>;
  if (isError || !data) return <div className="mx-auto max-w-[1420px]"><PageHeader eyebrow="Mission control" title="Workspace overview" description="The shortest path from everything your team knows to what you need next." /><ErrorPanel onRetry={() => refetch()} /></div>;
  const { stats, sources, risks, entities, latestCompilation } = data;
   return (
    <div className="mx-auto max-w-[1420px]">
       <PageHeader eyebrow="Workspace overview" title={<>Your workspace <span className="text-primary">is ready.</span></>} description="Start with a note or authorize a source. Weave will only show context that exists in this workspace." action={<div className="flex flex-wrap gap-2"><Link href="/capture" className="flex w-fit items-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground shadow-[0_6px_18px_hsl(196_77%_37%_/_0.18)] transition hover:-translate-y-0.5 hover:bg-foreground" data-testid="link-start-capture"><NotebookPen className="h-4 w-4" /> Capture a note <ChevronRight className="h-4 w-4" /></Link><Link href="/graph" className="flex w-fit items-center gap-2 rounded-lg border border-border bg-card px-4 py-2.5 text-sm font-bold transition hover:border-primary hover:text-primary" data-testid="link-connect-sources"><Link2 className="h-4 w-4" /> Connect sources</Link></div>} />
      <section className="mb-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-5 fade-up">
        <Metric label="Open contradictions" value={stats.openRisks} detail="Need a decision before action" accent="accent" />
        <Metric label="Resolved aliases" value={stats.aliases} detail="Names Weave has connected" />
        <Metric label="Context reductions" value={stats.compilations} detail="Goals compiled this month" accent="green" />
        <Metric label="Captured moments" value={stats.captures} detail="Informal notes made useful" />
        <Metric label="Avg. reduction" value={`${stats.reduction}%`} detail="Less noise per compilation" accent="accent" />
      </section>
       <div className="grid gap-5 xl:grid-cols-[1.35fr_.85fr]">
        <section className="overflow-hidden rounded-xl border border-border bg-card fade-up fade-up-delay" data-testid="panel-graph-snapshot">
          <div className="flex items-start justify-between border-b border-border px-5 py-4 sm:px-6"><div><p className="font-serif text-lg font-bold">Context graph</p><p className="mt-0.5 text-xs text-muted-foreground">{entities.length} entities · {data.relations.length} relationships · confidence-weighted</p></div><Link href="/graph" className="flex items-center gap-1 text-xs font-bold text-primary hover:underline" data-testid="link-open-graph">Explore graph <ArrowUpRight className="h-3.5 w-3.5" /></Link></div>
           <div className="relative h-[310px] overflow-hidden bg-[radial-gradient(circle_at_50%_45%,hsl(185_66%_66%_/_0.13),transparent_35%)] p-5 sm:h-[350px]"><div className="absolute inset-0 opacity-50" style={{ backgroundImage: 'radial-gradient(hsl(225 27% 30% / .16) 1px, transparent 1px)', backgroundSize: '18px 18px' }} />{entities.length > 0 ? <><svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">{data.relations.map((relation, index) => { const source = entities.find(entity => entity.id === relation.sourceId); const target = entities.find(entity => entity.id === relation.targetId); return source && target ? <line key={`${relation.sourceId}-${relation.targetId}-${index}`} x1={source.x} y1={source.y} x2={target.x} y2={target.y} stroke="hsl(var(--primary) / .22)" strokeWidth=".28" /> : null; })}</svg>{entities.slice(0, 9).map(entity => <Link href="/graph" key={entity.id} className="absolute z-10 flex -translate-x-1/2 -translate-y-1/2 items-center gap-2 rounded-full border border-primary/20 bg-card/95 px-2.5 py-1.5 shadow-[0_4px_14px_hsl(225_30%_20%_/_0.1)] transition hover:scale-105 hover:border-primary" style={{ left: `${entity.x}%`, top: `${entity.y}%` }} data-testid={`node-overview-${entity.id}`}><span className={cn('h-2 w-2 rounded-full', entity.type === 'person' ? 'bg-accent' : entity.type === 'decision' ? 'bg-emerald-500' : 'bg-primary')} /><span className="max-w-[90px] truncate text-[10px] font-bold">{entity.label}</span></Link>)}</> : <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center" data-testid="empty-graph-snapshot"><div className="mb-3 flex h-11 w-11 items-center justify-center rounded-full bg-card/80 text-primary shadow-sm"><Network className="h-5 w-5" /></div><p className="font-serif text-lg font-bold">Your graph starts with context</p><p className="mt-1 max-w-sm text-sm leading-6 text-muted-foreground">Capture a note or connect a source to create entities and relationships.</p><Link href="/capture" className="mt-4 text-xs font-bold text-primary hover:underline" data-testid="link-snapshot-capture">Capture your first note</Link></div>}</div>
        </section>
         <div className="space-y-5 fade-up fade-up-delay-2"><SourceRail sources={sources} /><section className="rounded-xl border border-border bg-card" data-testid="panel-active-risks"><div className="flex items-center justify-between border-b border-border px-5 py-4"><div><p className="font-serif text-lg font-bold">Active contradictions</p><p className="mt-0.5 text-xs text-muted-foreground">Signals found in connected context</p></div><Link href="/risks" className="text-xs font-bold text-primary hover:underline" data-testid="link-all-risks">See all</Link></div><div className="space-y-2 p-3">{risks.filter(r => r.status === 'open').slice(0, 3).map(risk => <div key={risk.id} className="flex gap-3 rounded-lg p-2.5 transition hover:bg-secondary"><span className={cn('mt-1 h-2 w-2 shrink-0 rounded-full', risk.severity === 'high' ? 'bg-destructive' : 'bg-accent')} /><div className="min-w-0"><p className="truncate text-sm font-semibold">{risk.title}</p><p className="mt-0.5 truncate text-xs text-muted-foreground">{risk.body}</p></div></div>)}{risks.filter(r => r.status === 'open').length === 0 && <div className="p-4 text-center text-sm text-muted-foreground" data-testid="empty-active-risks">No contradictions detected from connected context yet.</div>}</div></section></div>
       </div>
      {latestCompilation && <section className="mt-5 rounded-xl border border-primary/20 bg-primary/[.05] p-5 sm:p-6" data-testid="panel-latest-compilation"><div className="flex flex-col gap-4 sm:flex-row sm:items-center"><div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-foreground"><Zap className="h-5 w-5" /></div><div className="min-w-0 flex-1"><p className="font-mono text-[10px] uppercase tracking-[0.18em] text-primary">Latest compilation</p><p className="mt-1 truncate font-serif text-lg font-bold">{latestCompilation.goal}</p><p className="mt-1 text-xs text-muted-foreground">{formatTokens(latestCompilation.rawTokens)} tokens reduced to {formatTokens(latestCompilation.compiledTokens)} · {latestCompilation.reduction}% less to read</p></div><Link href="/ask" className="flex items-center gap-2 text-xs font-bold text-primary" data-testid="link-view-compilation">View trace <ArrowUpRight className="h-3.5 w-3.5" /></Link></div></section>}
    </div>
  );
}

function GraphPage() {
  const entitiesQuery = useListEntities({ query: { queryKey: getListEntitiesQueryKey() } });
  const workspaceQuery = useGetWorkspaceState({ query: { queryKey: getGetWorkspaceStateQueryKey() } });
  const [selectedId, setSelectedId] = useState('');
  const [filter, setFilter] = useState('');
  const entities = entitiesQuery.data ?? [];
  const selected = selectedId || entities[0]?.id || 'none';
  const entityQuery = useGetEntity(selected, { query: { queryKey: getGetEntityQueryKey(selected), enabled: selected !== 'none' } });
  const visible = entities.filter(entity => `${entity.label} ${entity.type} ${entity.aliases.map(a => a.value).join(' ')}`.toLowerCase().includes(filter.toLowerCase()));
  const relations = workspaceQuery.data?.relations ?? [];
  const visibleIds = new Set(visible.map(entity => entity.id));
  return (
    <div className="mx-auto max-w-[1420px]"><PageHeader eyebrow="Resolved knowledge" title="Entity graph" description="A map of entities and relationships returned by your workspace. Nothing is inferred for display." action={<div className="flex items-center gap-2 rounded-lg border border-border bg-card px-3 py-2 font-mono text-[10px] text-muted-foreground"><CircleDot className="h-3.5 w-3.5 text-emerald-500" /> {entities.length} entities</div>} />
      {entitiesQuery.isLoading || workspaceQuery.isLoading ? <LoadingPanel label="Reading workspace graph" /> : entitiesQuery.isError || workspaceQuery.isError ? <ErrorPanel onRetry={() => { entitiesQuery.refetch(); workspaceQuery.refetch(); }} /> : entities.length === 0 ? <section className="flex min-h-[430px] flex-col items-center justify-center rounded-xl border border-dashed border-border bg-card/55 p-8 text-center" data-testid="empty-entities"><div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10 text-primary"><Network className="h-6 w-6" /></div><p className="font-serif text-2xl font-bold">The graph is waiting for context</p><p className="mt-2 max-w-md text-sm leading-6 text-muted-foreground">Entities appear after you add a capture or authorize a source. Start with one real note, then return here to inspect what Weave resolved.</p><Link href="/capture" className="mt-5 flex items-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground transition hover:bg-foreground" data-testid="link-graph-capture"><NotebookPen className="h-4 w-4" /> Capture a note <ChevronRight className="h-4 w-4" /></Link></section> : <div className="grid gap-5 xl:grid-cols-[1fr_355px]"><section className="rounded-xl border border-border bg-card p-4 sm:p-5" data-testid="panel-entity-map"><div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"><div><p className="font-serif text-lg font-bold">Resolved map</p><p className="text-xs text-muted-foreground">{relations.length} relationships returned by the workspace</p></div><div className="relative"><Search className="absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" /><input value={filter} onChange={e => setFilter(e.target.value)} placeholder="Find an entity" className="h-9 w-full rounded-md border border-border bg-background pl-9 pr-3 text-xs outline-none transition focus:border-primary sm:w-48" data-testid="input-search-entities" /></div></div><div className="relative h-[500px] overflow-hidden rounded-lg border border-border/70 bg-background"><div className="absolute inset-0 opacity-70" style={{ backgroundImage: 'linear-gradient(hsl(225 20% 25% / .05) 1px,transparent 1px),linear-gradient(90deg,hsl(225 20% 25% / .05) 1px,transparent 1px)', backgroundSize: '26px 26px' }} /><svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">{relations.filter(relation => visibleIds.has(relation.sourceId) && visibleIds.has(relation.targetId)).map((relation, index) => { const source = visible.find(entity => entity.id === relation.sourceId); const target = visible.find(entity => entity.id === relation.targetId); return source && target ? <line key={`${relation.sourceId}-${relation.targetId}-${index}`} x1={source.x} y1={source.y} x2={target.x} y2={target.y} stroke="hsl(var(--primary) / .25)" strokeWidth=".3" /> : null; })}</svg>{visible.map(entity => <button key={entity.id} onClick={() => setSelectedId(entity.id)} className={cn('absolute z-10 flex -translate-x-1/2 -translate-y-1/2 items-center gap-2 rounded-full border px-3 py-2 shadow-[0_4px_16px_hsl(225_30%_20%_/_0.1)] transition hover:scale-105', selected === entity.id ? 'border-primary bg-primary text-primary-foreground' : 'border-border bg-card hover:border-primary')} style={{ left: `${entity.x}%`, top: `${entity.y}%` }} data-testid={`button-entity-${entity.id}`}><span className={cn('h-2 w-2 rounded-full', entity.type === 'person' ? 'bg-accent' : entity.type === 'decision' ? 'bg-emerald-500' : selected === entity.id ? 'bg-primary-foreground' : 'bg-primary')} /><span className="max-w-[115px] truncate text-[11px] font-bold">{entity.label}</span></button>)}{visible.length === 0 && <div className="absolute inset-0 flex items-center justify-center text-sm text-muted-foreground" data-testid="empty-filtered-entities">No entities match this search.</div>}</div></section><EntityDetail entity={entityQuery.data ?? entities.find(e => e.id === selected)} isLoading={entityQuery.isLoading} /></div>}
    </div>
  );
}

function EntityDetail({ entity, isLoading }: { entity?: Entity; isLoading: boolean }) {
  if (isLoading) return <LoadingPanel label="Loading merge evidence" />;
  if (!entity) return <div className="flex min-h-64 items-center justify-center rounded-xl border border-dashed border-border text-sm text-muted-foreground" data-testid="empty-entity-detail">Select an entity to inspect.</div>;
  return <aside className="rounded-xl border border-border bg-card p-5" data-testid="panel-entity-detail"><div className="mb-5 flex items-start justify-between"><div><span className="rounded-full bg-primary/10 px-2 py-1 font-mono text-[9px] font-bold uppercase tracking-widest text-primary">{entity.type}</span><h2 className="mt-3 font-serif text-2xl font-bold tracking-tight">{entity.label}</h2></div><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-secondary text-primary"><Link2 className="h-5 w-5" /></div></div><div className="mb-5 grid grid-cols-2 gap-2"><div className="rounded-lg bg-secondary p-3"><p className="font-mono text-[9px] uppercase tracking-widest text-muted-foreground">Confidence</p><p className="mt-1 font-serif text-xl font-bold">{entity.confidence == null ? '—' : `${Math.round(entity.confidence * 100)}%`}</p></div><div className="rounded-lg bg-secondary p-3"><p className="font-mono text-[9px] uppercase tracking-widest text-muted-foreground">Connections</p><p className="mt-1 font-serif text-xl font-bold">{entity.connections.length}</p></div></div><p className="mb-3 font-mono text-[10px] font-bold uppercase tracking-[0.18em] text-muted-foreground">Alias evidence</p><div className="space-y-2">{entity.aliases.length ? entity.aliases.map((alias, i) => <div key={`${alias.value}-${i}`} className="flex items-center justify-between rounded-lg border border-border px-3 py-2.5" data-testid={`alias-${i}`}><span className="text-sm font-semibold">{alias.value}</span><span className="font-mono text-[9px] uppercase text-muted-foreground">{alias.source}</span></div>) : <p className="text-sm text-muted-foreground" data-testid="empty-aliases">No aliases merged.</p>}</div>{entity.evidence && <div className="mt-5 border-t border-border pt-5"><p className="mb-2 font-mono text-[10px] font-bold uppercase tracking-[0.18em] text-muted-foreground">Why this is connected</p><p className="text-sm leading-6 text-muted-foreground">{entity.evidence}</p></div>}<div className="mt-5 flex items-center gap-2 text-xs text-muted-foreground"><GitBranch className="h-3.5 w-3.5" /> {entity.connections.slice(0, 3).join(' · ') || 'No named connections'}</div></aside>;
}

function AskPage() {
  const [goal, setGoal] = useState('');
  const [result, setResult] = useState<ReturnType<typeof useCompileContext>['data']>(undefined);
  const compilations = useListCompilations({ query: { queryKey: getListCompilationsQueryKey() } });
  const workspace = useGetWorkspaceState({ query: { queryKey: getGetWorkspaceStateQueryKey() } });
  const compile = useCompileContext();
  const qc = useQueryClient();
  const hasContext = (workspace.data?.entities.length ?? 0) > 0 || (workspace.data?.stats.captures ?? 0) > 0 || (workspace.data?.sources.some(source => source.count.trim() !== '' && source.count !== '0') ?? false);
  const submit = () => { if (!goal.trim() || !hasContext) return; compile.mutate({ data: { goal: goal.trim() } }, { onSuccess: (data) => { setResult(data); qc.invalidateQueries({ queryKey: getListCompilationsQueryKey() }); qc.invalidateQueries({ queryKey: getGetWorkspaceStateQueryKey() }); } }); };
  return <div className="mx-auto max-w-[1200px]"><PageHeader eyebrow="Context compiler" title="Ask Weave" description="Give Weave a goal. It will trace the shortest route through your workspace and return only the context needed to act." /><div className="grid gap-5 xl:grid-cols-[1fr_360px]"><section className="space-y-5"><div className="rounded-xl border border-border bg-card p-5 sm:p-7" data-testid="panel-goal-input"><div className="mb-4 flex items-center gap-3"><div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary/10 text-primary"><Terminal className="h-4 w-4" /></div><div><p className="font-serif text-lg font-bold">What are you trying to do?</p><p className="text-xs text-muted-foreground">Be specific. A goal, not a question.</p></div></div><textarea value={goal} onChange={e => setGoal(e.target.value)} placeholder="Write a goal once your workspace has context…" maxLength={500} className="min-h-32 w-full resize-none rounded-lg border border-border bg-background p-4 text-sm leading-6 outline-none transition placeholder:text-muted-foreground/60 focus:border-primary focus:ring-2 focus:ring-primary/10" data-testid="textarea-goal" />{!workspace.isLoading && !workspace.isError && !hasContext && <div className="mt-3 flex items-start gap-2 rounded-lg border border-dashed border-border bg-secondary/35 p-3 text-xs leading-5 text-muted-foreground" data-testid="status-compile-disabled"><Inbox className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" /><span>Compile becomes available after you capture a note or sync usable context from an authorized source.</span></div>}<div className="mt-3 flex items-center justify-between"><span className="font-mono text-[10px] text-muted-foreground">{goal.length}/500</span><button onClick={submit} disabled={!goal.trim() || !hasContext || compile.isPending || workspace.isLoading} className="flex items-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground transition hover:bg-foreground disabled:cursor-not-allowed disabled:opacity-45" data-testid="button-compile">{compile.isPending ? <><Loader2 className="h-4 w-4 animate-spin" /> Tracing context…</> : <><Sparkles className="h-4 w-4" /> Compile context</>}</button></div>{compile.isError && <p className="mt-3 flex items-center gap-2 text-xs text-destructive" data-testid="status-compile-error"><TriangleAlert className="h-3.5 w-3.5" /> Weave could not compile that goal. Try adding a little more detail.</p>}</div>{result && <CompilationResult result={result} />}{!result && <div className="flex min-h-52 flex-col items-center justify-center rounded-xl border border-dashed border-border bg-card/45 p-8 text-center" data-testid="empty-compilation"><div className="mb-3 flex h-11 w-11 items-center justify-center rounded-full bg-secondary text-muted-foreground"><ArrowDownRight className="h-5 w-5" /></div><p className="font-serif text-lg font-bold">Your trace will appear here</p><p className="mt-1 max-w-sm text-sm leading-6 text-muted-foreground">Weave will show what it included, what it left out, and why once usable context exists.</p></div>}</section><section className="rounded-xl border border-border bg-card" data-testid="panel-compilation-history"><div className="border-b border-border px-5 py-4"><p className="font-serif text-lg font-bold">Compilation history</p><p className="mt-0.5 text-xs text-muted-foreground">Previous goals, ready to revisit</p></div><div className="divide-y divide-border">{compilations.isLoading ? <div className="space-y-3 p-5"><Skeleton className="h-10 w-full" /><Skeleton className="h-10 w-full" /><Skeleton className="h-10 w-full" /></div> : (compilations.data ?? []).slice(0, 8).map(item => <button key={item.id} onClick={() => { setGoal(item.goal); setResult(item); }} className="group w-full px-5 py-4 text-left transition hover:bg-secondary" data-testid={`button-history-${item.id}`}><div className="flex items-start justify-between gap-3"><p className="line-clamp-2 text-sm font-semibold leading-5">{item.goal}</p><ChevronRight className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground transition group-hover:translate-x-0.5 group-hover:text-primary" /></div><div className="mt-2 flex items-center justify-between font-mono text-[9px] uppercase tracking-wider text-muted-foreground"><span>{formatDate(item.createdAt)}</span><span className="text-emerald-700">{item.reduction}% reduced</span></div></button>)}{!compilations.isLoading && (compilations.data ?? []).length === 0 && <div className="p-6 text-center text-sm text-muted-foreground" data-testid="empty-history">No compilations yet.</div>}</div></section></div></div>;
}

function CompilationResult({ result }: { result: NonNullable<ReturnType<typeof useCompileContext>['data']> }) {
  return <section className="rounded-xl border border-primary/20 bg-card" data-testid="panel-compilation-result"><div className="flex flex-col gap-5 border-b border-border bg-primary/[.045] p-5 sm:flex-row sm:items-center sm:p-6"><div className="relative flex h-16 w-16 shrink-0 items-center justify-center rounded-full border-[5px] border-primary/20 bg-card"><span className="font-serif text-lg font-bold text-primary">{result.reduction}%</span><span className="absolute -bottom-1 rounded bg-primary px-1.5 font-mono text-[8px] uppercase tracking-widest text-primary-foreground">less</span></div><div className="min-w-0"><p className="font-mono text-[10px] uppercase tracking-[.18em] text-primary">Minimum sufficient context</p><h2 className="mt-1 font-serif text-xl font-bold">Ready to act on “{result.goal}”</h2><p className="mt-1 text-xs text-muted-foreground">{formatTokens(result.rawTokens)} raw tokens → {formatTokens(result.compiledTokens)} compiled tokens</p></div></div><div className="p-5 sm:p-6"><div className="mb-6"><p className="mb-3 font-mono text-[10px] font-bold uppercase tracking-[.18em] text-muted-foreground">Compilation trace</p><div className="space-y-0">{result.steps.map((step, index) => <div key={`${step.title}-${index}`} className="relative flex gap-3 pb-4 last:pb-0"><div className="relative z-10 mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground"><Check className="h-3 w-3" /></div>{index < result.steps.length - 1 && <div className="absolute left-[9px] top-5 h-full w-px bg-primary/20" />}<div><p className="text-sm font-bold">{step.title}</p><p className="mt-0.5 text-xs leading-5 text-muted-foreground">{step.detail}</p></div></div>)}</div></div><div className="grid gap-4 sm:grid-cols-2"><div className="rounded-lg border border-emerald-200 bg-emerald-50/60 p-4"><p className="mb-3 flex items-center gap-2 font-mono text-[10px] font-bold uppercase tracking-widest text-emerald-700"><CheckCircle2 className="h-3.5 w-3.5" /> Included</p><div className="space-y-2">{result.included.map((item, i) => <p key={`${item}-${i}`} className="flex items-start gap-2 text-xs leading-5 text-emerald-950"><span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-emerald-600" />{item}</p>)}</div></div><div className="rounded-lg border border-border bg-secondary/45 p-4"><p className="mb-3 flex items-center gap-2 font-mono text-[10px] font-bold uppercase tracking-widest text-muted-foreground"><Unplug className="h-3.5 w-3.5" /> Left out</p><div className="space-y-2">{result.excluded.map((item, i) => <p key={`${item}-${i}`} className="flex items-start gap-2 text-xs leading-5 text-muted-foreground"><span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-muted-foreground/50" />{item}</p>)}</div></div></div></div></section>;
}

function CapturePage() {
  const captures = useListCaptures({ query: { queryKey: getListCapturesQueryKey() } });
  const create = useCreateCapture();
  const qc = useQueryClient();
  const [kind, setKind] = useState<'handwriting' | 'voice'>('handwriting');
  const [transcript, setTranscript] = useState('');
  const [success, setSuccess] = useState<Capture | null>(null);
  const submit = () => { if (!transcript.trim()) return; create.mutate({ data: { kind, transcript: transcript.trim() } }, { onSuccess: (data) => { setSuccess(data); setTranscript(''); qc.invalidateQueries({ queryKey: getListCapturesQueryKey() }); qc.invalidateQueries({ queryKey: getGetWorkspaceStateQueryKey() }); } }); };
  return <div className="mx-auto max-w-[1200px]"><PageHeader eyebrow="Unstructured → useful" title="Capture a moment" description="A scribble, a voice memo, a thought in transit. Weave structures it so it can become part of the graph." action={<div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-widest text-muted-foreground"><Inbox className="h-4 w-4 text-primary" /> {captures.data?.length ?? 0} records</div>} /><div className="grid gap-5 lg:grid-cols-[1fr_390px]"><section className="rounded-xl border border-border bg-card p-5 sm:p-7" data-testid="panel-capture-composer"><div className="mb-6 flex gap-2 rounded-lg bg-secondary p-1"><button onClick={() => setKind('handwriting')} className={cn('flex flex-1 items-center justify-center gap-2 rounded-md px-3 py-2.5 text-xs font-bold transition', kind === 'handwriting' ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground')} data-testid="button-capture-handwriting"><PenLine className="h-4 w-4" /> Handwriting</button><button onClick={() => setKind('voice')} className={cn('flex flex-1 items-center justify-center gap-2 rounded-md px-3 py-2.5 text-xs font-bold transition', kind === 'voice' ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground')} data-testid="button-capture-voice"><Mic className="h-4 w-4" /> Voice note</button></div>{kind === 'handwriting' ? <div className="mb-5 rounded-lg border border-dashed border-primary/30 bg-primary/[.035] p-8 text-center"><div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary"><PenLine className="h-5 w-5" /></div><p className="font-serif text-lg font-bold">What did you write down?</p><p className="mt-1 text-xs leading-5 text-muted-foreground">Paste a transcription or describe the note in your own words.</p></div> : <div className="mb-5 rounded-lg border border-dashed border-accent/40 bg-accent/[.045] p-8 text-center"><div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-accent/15 text-accent"><AudioLines className="h-5 w-5" /></div><p className="font-serif text-lg font-bold">Voice memo transcript</p><p className="mt-1 text-xs leading-5 text-muted-foreground">Drop in the transcript. Weave will find the signal.</p></div>}<textarea value={transcript} onChange={e => setTranscript(e.target.value)} placeholder={kind === 'handwriting' ? 'The payment webhook needs a retry policy…' : 'I was thinking about how the new onboarding flow…'} className="min-h-36 w-full resize-none rounded-lg border border-border bg-background p-4 text-sm leading-6 outline-none transition placeholder:text-muted-foreground/60 focus:border-primary focus:ring-2 focus:ring-primary/10" data-testid="textarea-capture" /><div className="mt-3 flex items-center justify-between"><span className="font-mono text-[10px] text-muted-foreground">{transcript.length}/5000</span><button onClick={submit} disabled={!transcript.trim() || create.isPending} className="flex items-center gap-2 rounded-lg bg-foreground px-4 py-2.5 text-sm font-bold text-background transition hover:bg-primary disabled:opacity-45" data-testid="button-structure-capture">{create.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Zap className="h-4 w-4" />} Structure this</button></div>{success && <div className="mt-4 flex items-start gap-2 rounded-lg bg-emerald-50 p-3 text-xs text-emerald-800" data-testid="status-capture-success"><CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" /><span><b>{success.title}</b> added to the workspace.</span></div>}{create.isError && <p className="mt-3 text-xs text-destructive" data-testid="status-capture-error">This capture could not be structured. Try again.</p>}</section><CaptureHistory captures={captures.data ?? []} isLoading={captures.isLoading} /></div></div>;
}

function CaptureHistory({ captures, isLoading }: { captures: Capture[]; isLoading: boolean }) {
  return <section className="rounded-xl border border-border bg-card" data-testid="panel-capture-history"><div className="border-b border-border px-5 py-4"><p className="font-serif text-lg font-bold">Structured records</p><p className="mt-0.5 text-xs text-muted-foreground">The informal becomes searchable</p></div>{isLoading ? <div className="space-y-3 p-5"><Skeleton className="h-20 w-full" /><Skeleton className="h-20 w-full" /></div> : captures.length === 0 ? <div className="flex min-h-56 flex-col items-center justify-center p-6 text-center"><div className="mb-3 flex h-10 w-10 items-center justify-center rounded-full bg-secondary text-muted-foreground"><Inbox className="h-4 w-4" /></div><p className="text-sm font-semibold">Nothing captured yet</p><p className="mt-1 text-xs text-muted-foreground">Your next thought can start here.</p></div> : <div className="divide-y divide-border">{captures.map(capture => <div key={capture.id} className="p-5 transition hover:bg-secondary/50" data-testid={`card-capture-${capture.id}`}><div className="flex items-start gap-3"><div className={cn('flex h-8 w-8 shrink-0 items-center justify-center rounded-lg', capture.kind === 'voice' ? 'bg-accent/15 text-accent' : 'bg-primary/10 text-primary')}>{capture.kind === 'voice' ? <Mic className="h-4 w-4" /> : <PenLine className="h-4 w-4" />}</div><div className="min-w-0"><p className="text-sm font-bold">{capture.title}</p><p className="mt-1 font-mono text-[9px] uppercase tracking-widest text-muted-foreground">{capture.source} · {formatDate(capture.createdAt)}</p></div></div><div className="mt-3 flex flex-wrap gap-1.5">{capture.fields.slice(0, 3).map((field, i) => <span key={`${field.label}-${i}`} className="rounded bg-secondary px-2 py-1 text-[10px] text-muted-foreground"><b className="text-foreground">{field.label}:</b> {field.value}</span>)}</div></div>)}</div>}</section>;
}

function RisksPage() {
  const risks = useListRisks({ query: { queryKey: getListRisksQueryKey() } });
  const resolve = useResolveRisk();
  const qc = useQueryClient();
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<'all' | 'open' | 'resolved'>('open');
  const list = useMemo(() => (risks.data ?? []).filter(risk => (filter === 'all' || risk.status === filter) && `${risk.title} ${risk.body} ${risk.severity}`.toLowerCase().includes(search.toLowerCase())), [risks.data, filter, search]);
  const resolveOne = (id: string) => resolve.mutate({ riskId: id }, { onSuccess: () => { qc.invalidateQueries({ queryKey: getListRisksQueryKey() }); qc.invalidateQueries({ queryKey: getGetWorkspaceStateQueryKey() }); } });
  return <div className="mx-auto max-w-[1100px]"><PageHeader eyebrow="Signal integrity" title="Contradictions" description="When sources disagree, Weave keeps the tension visible. Resolve a contradiction once the team has a decision." action={<div className="flex items-center gap-2 rounded-lg bg-accent/10 px-3 py-2 font-mono text-[10px] font-bold uppercase tracking-widest text-accent"><ShieldAlert className="h-3.5 w-3.5" /> {list.filter(r => r.status === 'open').length} open</div>} /><div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"><div className="relative max-w-sm flex-1"><Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" /><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search contradictions" className="h-10 w-full rounded-lg border border-border bg-card pl-10 pr-3 text-sm outline-none focus:border-primary" data-testid="input-search-risks" /></div><div className="flex rounded-lg border border-border bg-card p-1">{(['open', 'all', 'resolved'] as const).map(option => <button key={option} onClick={() => setFilter(option)} className={cn('rounded-md px-3 py-2 font-mono text-[10px] font-bold uppercase tracking-wider transition', filter === option ? 'bg-foreground text-background' : 'text-muted-foreground hover:text-foreground')} data-testid={`button-filter-${option}`}>{option}</button>)}</div></div>{risks.isLoading ? <div className="space-y-3"><LoadingPanel /><LoadingPanel /></div> : risks.isError ? <ErrorPanel onRetry={() => risks.refetch()} /> : <div className="space-y-3">{list.map(risk => <RiskCard key={risk.id} risk={risk} onResolve={resolveOne} resolving={resolve.isPending} />)}{list.length === 0 && <div className="flex min-h-64 flex-col items-center justify-center rounded-xl border border-dashed border-border bg-card/45 p-8 text-center" data-testid="empty-risks"><CheckCircle2 className="mb-3 h-7 w-7 text-emerald-600" /><p className="font-serif text-lg font-bold">{filter === 'open' ? 'No open contradictions' : 'No matching signals'}</p><p className="mt-1 text-sm text-muted-foreground">Your context is aligned for this view.</p></div>}</div>}</div>;
}

function AppRouter() {
  return <ErrorBoundary><Shell><Switch><Route path="/" component={Overview} /><Route path="/graph" component={GraphPage} /><Route path="/ask" component={AskPage} /><Route path="/capture" component={CapturePage} /><Route path="/risks" component={RisksPage} /><Route component={NotFound} /></Switch></Shell></ErrorBoundary>;
}

export default function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><AppRouter /><Toaster /></TooltipProvider></QueryClientProvider>;
}