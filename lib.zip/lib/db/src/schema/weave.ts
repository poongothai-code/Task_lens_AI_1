import { boolean, jsonb, pgTable, real, text, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const weaveSourcesTable = pgTable("weave_sources", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  count: text("count").notNull(),
  status: text("status").notNull().default("ready"),
  lastSyncedAt: timestamp("last_synced_at", { withTimezone: true }),
});

export const weaveEntitiesTable = pgTable("weave_entities", {
  id: text("id").primaryKey(),
  label: text("label").notNull(),
  type: text("type").notNull(),
  x: real("x").notNull(),
  y: real("y").notNull(),
  confidence: real("confidence"),
  aliases: jsonb("aliases").$type<Array<{ value: string; source: string }>>().notNull().default([]),
  evidence: text("evidence"),
  connections: jsonb("connections").$type<string[]>().notNull().default([]),
});

export const weaveRelationsTable = pgTable("weave_relations", {
  id: text("id").primaryKey(),
  sourceId: text("source_id").notNull(),
  targetId: text("target_id").notNull(),
  label: text("label").notNull(),
});

export const weaveRisksTable = pgTable("weave_risks", {
  id: text("id").primaryKey(),
  severity: text("severity").notNull(),
  title: text("title").notNull(),
  body: text("body").notNull(),
  status: text("status").notNull().default("open"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  resolvedAt: timestamp("resolved_at", { withTimezone: true }),
});

export const weaveCompilationsTable = pgTable("weave_compilations", {
  id: text("id").primaryKey(),
  goal: text("goal").notNull(),
  rawTokens: real("raw_tokens").notNull(),
  compiledTokens: real("compiled_tokens").notNull(),
  reduction: real("reduction").notNull(),
  steps: jsonb("steps").$type<Array<{ title: string; detail: string }>>().notNull(),
  included: jsonb("included").$type<string[]>().notNull(),
  excluded: jsonb("excluded").$type<string[]>().notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const weaveCapturesTable = pgTable("weave_captures", {
  id: text("id").primaryKey(),
  kind: text("kind").notNull(),
  title: text("title").notNull(),
  fields: jsonb("fields").$type<Array<{ label: string; value: string }>>().notNull(),
  source: text("source").notNull(),
  transcript: text("transcript"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertWeaveSourceSchema = createInsertSchema(weaveSourcesTable);
export const insertWeaveEntitySchema = createInsertSchema(weaveEntitiesTable);
export const insertWeaveRelationSchema = createInsertSchema(weaveRelationsTable);
export const insertWeaveRiskSchema = createInsertSchema(weaveRisksTable);
export const insertWeaveCompilationSchema = createInsertSchema(weaveCompilationsTable);
export const insertWeaveCaptureSchema = createInsertSchema(weaveCapturesTable);

export type WeaveSource = z.infer<typeof insertWeaveSourceSchema>;
export type WeaveEntity = z.infer<typeof insertWeaveEntitySchema>;
export type WeaveRelation = z.infer<typeof insertWeaveRelationSchema>;
export type WeaveRisk = z.infer<typeof insertWeaveRiskSchema>;
export type WeaveCompilation = z.infer<typeof insertWeaveCompilationSchema>;
export type WeaveCapture = z.infer<typeof insertWeaveCaptureSchema>;